

var myVar = setInterval(myFunction, 1000);

function toggle_visibility(id) {
       var e = document.getElementsByClassName(id);
     	e[0].style.display = ((e[0].style.display!='none') ? 'none' : 'block');
     	if(e[0].style.display = 'block')
     	{
     		document.getElementsByClassName('start')[0].style.display = 'none';
//     		call();
     	}

 }


 // Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function myFunction() {
   
	var val_1 = Math.floor((Math.random() * 100) + 1);
	var val_2 = Math.floor((Math.random() * 100) + 1);
	var res = val_1 + val_2 ;


    var x = document.getElementById("operator1");
    var y = document.getElementById("operator2");
    y.innerHTML = val2;
    x.innerHTML = val_1;
    //console.log('32');
    var z = document.getElementById("operand");
    var result = document.getElementById("result");
    result.innerHTML = res;
}

